=== Powerpay para WooCommerce ===
Contributors: renzotejada, huakotech
Tags: powerpay, pagos
Requires at least: 5.2
Tested up to: 6.7.2
Stable tag: trunk
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Este plugin agrega el método de pago Powerpay para Woocommerce

Compra ahora y paga después con Powerpay, tu nueva forma de pago con cuotas desde 0% intereses.

== Description ==

Este plugin agrega el método de pago Powerpay para Woocommerce

== Installation ==

ZIP files Installation manual
1. Download the ZIP file from this screen.
2. Select the add plugin option from the admin panel.
3. Select the heavy load option and select the downloaded file.
4. Confirm Installation and activation plugin from the administration panel.

Manual FTP installation
1. Download the ZIP file from this screen and unzip.
2. Go to your FTP folder on your web server.
3. Copy the directory ubigeo into the following address wp-content/plugins/
4. Activate the plugin from the WordPress administration panel.


== Changelog ==

= 3.8 =
Fix: corrigiendo errores warning de codigo fuente.

= 3.7 =
Fix: Se agrega la compatibilidad con checkout editor

= 3.6 =
Fix: Se agrega la compatibilidad de versión php8

= 3.5 =
Fix: Se agrega la gestión para el cambio de tema de widget.

= 3.4 =
Fix: Se agrega funcion para el cambio de tema.

= 3.3 =
Fix: Se agrega funcion para verificar el nombre del campo billing company para dni

= 3.2 =
Fix: Se agrega la funcionalidad de parametrización de campos del formulario del checkout.

= 3.1 =
Fix: Se corrige error de guardar metadata de woo con HPOS

= 3.0 =
Fix: Se agrega la compatibilidad del plugin con la version de Almacenamiento de pedidos de alto rendimiento (HPOS)

= 2.8 =
Fix: Se agrega una metadata para obtener el dato dni.

= 2.7 =
Fix: Se corrige error de cierre de etiqueta style.

= 2.6 =
Fix: Se agrega la gestión de mostrar los mensajes de respuesta del checkout.

= 2.5 =
Fix: Se agrega mensajes personalizados según status del pedido.

= 2.4 =
Fix: Se agrega un nuevo hook de detalle si sale widget después del precio o del botón añadir carrito.

= 2.3 =
Fix: Se agrega código de shortcode para los widgets del plugin para temas personalizados

= 2.2 =
Fix: Se corrige error de status del webhook

= 2.1 =
Fix: Se agrega mejora con el widget checkout del plugin

= 2.0 =
Fix: Se agrega compatibilidad del plugin con wordpress versión 6.0.6

= 1.9 =
Fix: Se agrega mejora de status del webhook.

= 1.8 =
Fix:Se agrega mejors de códigos de respuesta del webhook

= 1.7 =
Fix: Se corrige error de códigos de respuesta del webhook

= 1.6 =
Fix: Se agrega códigos de respuesta del webhook

= 1.3 =
Fix: Se agrega el campo DNI y la url del callback de powerpay en el admin

= 1.2 =
Fix: Actualizando texto del widget del checkout

= 1.0 =
Inicio



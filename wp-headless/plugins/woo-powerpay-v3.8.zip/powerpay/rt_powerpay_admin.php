<?php
if (!defined('ABSPATH')) {
    exit;
} // Exit if accessed directly
use Automattic\WooCommerce\Utilities\RestApiUtil;

add_action('admin_menu', 'rt_powerpay_register_admin_page');

function rt_powerpay_register_admin_page()
{
    add_submenu_page('woocommerce', 'Configuraciones', 'Powerpay', 'manage_woocommerce', 'rt_powerpay_settings', 'rt_powerpay_submenu_settings_callback');
    add_action('admin_init', 'rt_powerpay_register_settings');
}

function rt_powerpay_register_settings()
{
    register_setting('rt_powerpay_test_settings_group', 'rt_powerpay_mercand_id_test');
    register_setting('rt_powerpay_test_settings_group', 'rt_powerpay_client_key_test');
    register_setting('rt_powerpay_test_settings_group', 'rt_powerpay_secret_key_test');
    register_setting('rt_powerpay_pro_settings_group', 'rt_powerpay_mercand_id_pro');
    register_setting('rt_powerpay_pro_settings_group', 'rt_powerpay_client_key_pro');
    register_setting('rt_powerpay_pro_settings_group', 'rt_powerpay_secret_key_pro');
    register_setting('rt_powerpay_widget_group', 'rt_powerpay_header');
    register_setting('rt_powerpay_widget_group', 'rt_powerpay_banner');
    register_setting('rt_powerpay_widget_group', 'rt_powerpay_detalle');
    register_setting('rt_powerpay_widget_group', 'rt_powerpay_detalle_position');
    register_setting('rt_powerpay_widget_group', 'rt_powerpay_checkout');
    register_setting('rt_powerpay_widget_group', 'rt_powerpay_checkout_display');
    register_setting('rt_powerpay_widget_group', 'rt_powerpay_template_display');
    register_setting('rt_powerpay_form_group', 'rt_powerpay_form_first_name');
    register_setting('rt_powerpay_form_group', 'rt_powerpay_form_last_name');
    register_setting('rt_powerpay_form_group', 'rt_powerpay_form_document_number');
    register_setting('rt_powerpay_form_group', 'rt_powerpay_form_email');
    register_setting('rt_powerpay_form_group', 'rt_powerpay_form_phone_number');
    register_setting('rt_powerpay_form_group', 'rt_powerpay_form_shipping_address');
}

function rt_powerpay_success_notice()
{
    ?>
    <div class="updated notice">
        <p><?php _e('Was saved successfully', 'woo-powerpay') ?></p>
    </div>
    <?php
}

function rt_powerpay_submenu_settings_callback()
{
    if (isset($_REQUEST["settings-updated"]) && sanitize_text_field($_REQUEST["settings-updated"] == true)) {
        rt_powerpay_success_notice();
    } ?>
    <div class="wrap woocommerce">
        <div>
            <img style=" border-radius: 10px ;width: 100%; background-position: center; background-repeat: no-repeat;background-size: cover; height: 100%;"
                 src="<?php echo plugins_url('img/bg-powerpay.png', __FILE__); ?>" alt="">
        </div>

        <h2 class="nav-tab-wrapper">
            <a href="?page=rt_powerpay_settings&tab=settings" class="nav-tab <?php
            if ((!isset($_REQUEST['tab'])) || ($_REQUEST['tab'] == "settings")) {
                print " nav-tab-active";
            } ?>"><?php _e('Settings', 'woo-powerpay') ?></a>
            <a href="?page=rt_powerpay_settings&tab=widget" class="nav-tab <?php
            if (isset($_REQUEST['tab']) && $_REQUEST['tab'] == "widget") {
                print " nav-tab-active";
            } ?>"><?php _e('Widget', 'woo-powerpay') ?></a>
            <a href="?page=rt_powerpay_settings&tab=form" class="nav-tab <?php
            if (isset($_REQUEST['tab']) && $_REQUEST['tab'] == "form") {
                print " nav-tab-active";
            } ?>"><?php _e('Formulario', 'woo-powerpay') ?></a>
            <a href="?page=rt_powerpay_settings&tab=help" class="nav-tab <?php
            if (isset($_REQUEST['tab']) && $_REQUEST['tab'] == "help") {
                print " nav-tab-active";
            } ?>"><?php _e('Help', 'woo-powerpay') ?></a>

        </h2>
        <?php
        if ((!isset($_REQUEST['tab'])) || ($_REQUEST['tab'] == "settings")) {
            rt_powerpay_submenu_settings_settings();
        } elseif ($_REQUEST['tab'] == "settings") {
            rt_powerpay_submenu_settings_settings();
        } elseif ($_REQUEST['tab'] == "widget") {
            rt_powerpay_submenu_settings_widget();
        } elseif ($_REQUEST['tab'] == "form") {
            rt_powerpay_submenu_settings_formulario();
        } elseif ($_REQUEST['tab'] == "help") {
            rt_powerpay_submenu_settings_help();
        }
        ?>
    </div>
    <?php
}

function rt_powerpay_submenu_settings_settings()
{
    ?>
    <div class="wrap" style="background-color: #fff;">
        <div style="margin-top: 20px; padding: 20px 30px 10px 30px; background-color: #fff; min-height: 240px;width: 40%; float:left; margin-right: 20px;  border-radius: 10px ; background-position: center; background-repeat: no-repeat;background-size: cover; ">
            <h2><?php _e('Test credentials', 'woo-powerpay') ?></h2>
            <form method="post" action="options.php" id="rt_powerpay_test_formulario">
                <?php settings_fields('rt_powerpay_test_settings_group'); ?>
                <?php do_settings_sections('rt_powerpay_test_settings_group'); ?>
                <p>
                    <b><?php _e('Merchant ID', 'woo-powerpay') ?> </b> <span style="color: red;">&nbsp;*</span>
                    <input type="text" name="rt_powerpay_mercand_id_test" id="rt_powerpay_mercand_id_test"
                           placeholder=""
                           value="<?php echo get_option('rt_powerpay_mercand_id_test'); ?>"
                           style="width: 100%; padding: 10px;">
                </p>
                <p>
                    <b><?php _e('Client key', 'woo-powerpay') ?> </b><span style="color: red;">&nbsp;*</span>
                    <input type="text" name="rt_powerpay_client_key_test" id="rt_powerpay_client_key_test"
                           placeholder=""
                           value="<?php echo get_option('rt_powerpay_client_key_test'); ?>"
                           style="width: 100%; padding: 10px;">
                </p>
                <p>
                    <b><?php _e('Secret key', 'woo-powerpay') ?></b> <span style="color: red;">&nbsp;*</span>
                    <input type="text" name="rt_powerpay_secret_key_test" id="rt_powerpay_secret_key_test"
                           placeholder=""
                           value="<?php echo get_option('rt_powerpay_secret_key_test'); ?>"
                           style="width: 100%; padding: 10px;">
                </p>
                <p>
                    <?php submit_button(__('Save Changes', 'woo-powerpay')); ?>
                </p>
            </form>
        </div>
        <div style="margin-top: 20px; padding: 20px 30px 10px 30px; background-color: #fff; min-height: 240px;width: 40%; float:left; margin-right: 20px;  border-radius: 10px ; background-position: center; background-repeat: no-repeat;background-size: cover; ">
            <h2><?php _e('Production credentials', 'woo-powerpay') ?></h2>
            <form method="post" action="options.php" id="rt_powerpay_pro_formulario">
                <?php settings_fields('rt_powerpay_pro_settings_group'); ?>
                <?php do_settings_sections('rt_powerpay_pro_settings_group'); ?>
                <p>
                    <b><?php _e('Merchant ID', 'woo-powerpay') ?></b> <span style="color: red;">&nbsp;*</span>
                    <input type="text" name="rt_powerpay_mercand_id_pro" id="rt_powerpay_mercand_id_pro"
                           placeholder=""
                           value="<?php echo get_option('rt_powerpay_mercand_id_pro'); ?>"
                           style="width: 100%; padding: 10px;">
                </p>
                <p>
                    <b><?php _e('Client key', 'woo-powerpay') ?></b> <span style="color: red;">&nbsp;*</span>
                    <input type="text" name="rt_powerpay_client_key_pro" id="rt_powerpay_client_key_pro"
                           placeholder=""
                           value="<?php echo get_option('rt_powerpay_client_key_pro'); ?>"
                           style="width: 100%; padding: 10px;">
                </p>
                <p>
                    <b><?php _e('Secret key', 'woo-powerpay') ?></b> <span style="color: red;">&nbsp;*</span>
                    <input type="text" name="rt_powerpay_secret_key_pro" id="rt_powerpay_secret_key_pro"
                           placeholder=""
                           value="<?php echo get_option('rt_powerpay_secret_key_pro'); ?>"
                           style="width: 100%; padding: 10px;">
                </p>
                <p>
                    <?php submit_button(__('Save Changes', 'woo-powerpay')); ?>
                </p>
            </form>
        </div>
    </div>
    <div class="wrap" style="background-color: #fff;">
        <div style="margin-top: 20px; padding: 20px 30px 10px 30px; background-color: #fff; min-height: 140px;width: 40%; float:left; margin-right: 20px;  border-radius: 10px ; background-position: center; background-repeat: no-repeat;background-size: cover; ">
            <h4>URL Callback de Powerpay </h4>
            <p>
                <input type="text" readonly value="<?php echo get_bloginfo('wpurl'); ?>/wc-api/powerpay_status_order"
                       style="width: 100%; padding: 10px;">
            </p>
        </div>
    </div>

    <?php
}

function rt_powerpay_submenu_settings_widget()
{
    ?>
    <div class="wrap" style="background-color: #fff;">
        <div style="margin-top: 20px; padding: 20px 30px 10px 30px; background-color: #fff; min-height: 240px;width: 30%; float:left; margin-right: 20px;  border-radius: 10px ; background-position: center; background-repeat: no-repeat;background-size: cover; ">
            <h2><?php _e('Widget', 'woo-powerpay') ?></h2>
            <form method="post" action="options.php" id="rt_powerpay_widget_formulario">
                <?php settings_fields('rt_powerpay_widget_group'); ?>
                <?php do_settings_sections('rt_powerpay_widget_group'); ?>

                <table class="form-table">
                    <tbody>
                    <tr valign="top">
                        <th scope="row" class="titledesc" style="width: auto !important;">
                            <label><?php _e('Header page', 'woo-powerpay') ?></label>
                        </th>
                        <td class="forminp forminp-checkbox">
                            <input type="checkbox" name="rt_powerpay_header" id="rt_powerpay_header" value="on"
                                <?php if (esc_attr(get_option('rt_powerpay_header')) == "on") echo "checked"; ?> />
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row" class="titledesc" style="width: auto !important;">
                            <label><?php _e('Banner', 'woo-powerpay') ?></label>
                        </th>
                        <td class="forminp forminp-checkbox">
                            <input type="checkbox" name="rt_powerpay_banner" id="rt_powerpay_banner" value="on"
                                <?php if (esc_attr(get_option('rt_powerpay_banner')) == "on") echo "checked"; ?> />
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row" class="titledesc" style="width: auto !important;">
                            <label><?php _e('Page detail', 'woo-powerpay') ?></label>
                        </th>
                        <td class="forminp forminp-checkbox">
                            <input type="checkbox" name="rt_powerpay_detalle" id="rt_powerpay_detalle" value="on"
                                <?php if (esc_attr(get_option('rt_powerpay_detalle')) == "on") echo "checked"; ?> />
                        </td>
                        <td class="forminp forminp-checkbox">
                            <select name="rt_powerpay_detalle_position" id="rt_powerpay_detalle_position"
                                    style="width: auto !important;">
                                <?php $detalle_position = esc_attr(get_option('rt_powerpay_detalle_position'));
                                ?>
                                <option value="price" <?php echo $selected = ($detalle_position == 'price') ? 'selected' : '' ?> ><?php _e('Price', 'woo-powerpay') ?></option>
                                <option value="add_cart" <?php echo $selected = ($detalle_position == 'add_cart') ? 'selected' : '' ?> ><?php _e('Add to cart', 'woo-powerpay') ?></option>
                                <option value="before_add_cart" <?php echo $selected = ($detalle_position == 'before_add_cart') ? 'selected' : '' ?> ><?php _e('Before Add to cart', 'woo-powerpay') ?></option>
                            </select>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row" class="titledesc" style="width: auto !important;">
                            <label><?php _e('Page checkout', 'woo-powerpay') ?></label>
                        </th>
                        <td class="forminp forminp-checkbox">
                            <input type="checkbox" name="rt_powerpay_checkout" id="rt_powerpay_checkout" value="on"
                                <?php if (esc_attr(get_option('rt_powerpay_checkout')) == "on") echo "checked"; ?> />
                        </td>
                        <td class="forminp forminp-checkbox">
                            <select name="rt_powerpay_checkout_display" id="rt_powerpay_checkout_display"
                                    style="width: auto !important;">
                                <?php $checkout_display = esc_attr(get_option('rt_powerpay_checkout_display'));
                                ?>
                                <option value="return" <?php echo $selected = ($checkout_display == 'return') ? 'selected' : '' ?> ><?php _e('Return', 'woo-powerpay') ?></option>
                                <option value="echo" <?php echo $selected = ($checkout_display == 'echo') ? 'selected' : '' ?> ><?php _e('Echo', 'woo-powerpay') ?></option>
                            </select>
                        </td>
                    </tr>

                    <tr valign="top">
                        <th scope="row" class="titledesc" style="width: auto !important;">
                            <label><?php _e('Theme', 'woo-powerpay') ?></label>
                        </th>
                        <td class="forminp forminp-checkbox">

                        </td>
                        <td class="forminp forminp-checkbox">
                            <select name="rt_powerpay_template_display" id="rt_powerpay_template_display"
                                    style="width: auto !important;">
                                <?php $checkout_display = esc_attr(get_option('rt_powerpay_template_display'));
                                ?>
                                <option value="" <?php echo $selected = ($checkout_display == 'default') ? 'selected' : '' ?> ><?php _e('Default', 'woo-powerpay') ?></option>
                                <option value="white" <?php echo $selected = ($checkout_display == 'white') ? 'selected' : '' ?> ><?php _e('White', 'woo-powerpay') ?></option>
                                <option value="blue" <?php echo $selected = ($checkout_display == 'blue') ? 'selected' : '' ?> ><?php _e('Blue', 'woo-powerpay') ?></option>
                                <option value="bluewhite" <?php echo $selected = ($checkout_display == 'bluewhite') ? 'selected' : '' ?> ><?php _e('BlueWhite', 'woo-powerpay') ?></option>
                                <option value="black" <?php echo $selected = ($checkout_display == 'black') ? 'selected' : '' ?> ><?php _e('Black', 'woo-powerpay') ?></option>
                            </select>
                        </td>
                    </tr>
                    </tbody>
                </table>
                <?php submit_button(__('Save Changes', 'woo-powerpay')); ?>
            </form>
        </div>
    </div>
    <div class="wrap" style="background-color: #fff;">
        <div style="margin-top: 20px; padding: 20px 30px 10px 30px; background-color: #fff; min-height: 240px;width: 55%; float:left; margin-right: 20px;  border-radius: 10px ; background-position: center; background-repeat: no-repeat;background-size: cover; ">
            <h2><?php _e('Shortcode', 'woo-powerpay') ?></h2>
            <table class="form-table" style="width: auto !important;">
                <tbody>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label><?php _e('Header page', 'woo-powerpay') ?></label>
                    </th>
                    <td class="forminp forminp-checkbox" style="padding: 6px 10px;">
                        <pre>&lt;?php echo do_shortcode("[powerpay_widget_header]"); ?&gt;</pre>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label><?php _e('Banner', 'woo-powerpay') ?></label>
                    </th>
                    <td class="forminp forminp-checkbox" style="padding: 6px 10px;">
                        <pre>&lt;?php echo do_shortcode("[powerpay_widget_banner]"); ?&gt;</pre>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label><?php _e('Page detail', 'woo-powerpay') ?></label>
                    </th>
                    <td class="forminp forminp-checkbox" style="padding: 6px 10px;">
                        <pre>&lt;?php echo do_shortcode("[powerpay_widget_detail price="15.00"]"); ?&gt;</pre>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row" class="titledesc">
                        <label><?php _e('Page checkout', 'woo-powerpay') ?></label>
                    </th>
                    <td class="forminp forminp-checkbox" style="padding: 6px 10px;">
                        <pre>&lt;?php echo do_shortcode("[powerpay_widget_checkout total="90.00"]"); ?&gt;</pre>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
    <?php
}

function rt_powerpay_submenu_settings_formulario()
{
    ?>
    <div class="wrap" style="background-color: #fff;">
        <div style="margin-top: 20px; padding: 20px 30px 10px 30px; background-color: #fff; min-height: 440px;width: 40%; float:left; margin-right: 20px;  border-radius: 10px ; background-position: center; background-repeat: no-repeat;background-size: cover; ">
            <h2><?php _e('Formulario', 'woo-powerpay') ?></h2>
            <form method="post" action="options.php" id="rt_powerpay_form_formulario">
                <?php settings_fields('rt_powerpay_form_group'); ?>
                <?php do_settings_sections('rt_powerpay_form_group'); ?>

                <table class="form-table">
                    <tbody>
                    <tr valign="top">
                        <th scope="row" class="titledesc">
                            <label>Nombres - first_name</label>
                        </th>
                        <td class="forminp forminp-checkbox">
                            <input type="text" name="rt_powerpay_form_first_name" id="rt_powerpay_form_first_name"
                                   value="<?php echo esc_attr(get_option('rt_powerpay_form_first_name')) ?>"/>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row" class="titledesc">
                            <label>Apellidos - last_name</label>
                        </th>
                        <td class="forminp forminp-checkbox">
                            <input type="text" name="rt_powerpay_form_last_name" id="rt_powerpay_form_last_name"
                                   value="<?php echo esc_attr(get_option('rt_powerpay_form_last_name')) ?>"/>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row" class="titledesc">
                            <label>DNI - document_number</label>
                        </th>
                        <td class="forminp forminp-checkbox">
                            <input type="text" name="rt_powerpay_form_document_number"
                                   id="rt_powerpay_form_document_number"
                                   value="<?php echo esc_attr(get_option('rt_powerpay_form_document_number')) ?>"/>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row" class="titledesc">
                            <label>Correo - email</label>
                        </th>
                        <td class="forminp forminp-checkbox">
                            <input type="text" name="rt_powerpay_form_email" id="rt_powerpay_form_email"
                                   value="<?php echo esc_attr(get_option('rt_powerpay_form_email')) ?>"/>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row" class="titledesc">
                            <label>Celular - phone_number</label>
                        </th>
                        <td class="forminp forminp-checkbox">
                            <input type="text" name="rt_powerpay_form_phone_number" id="rt_powerpay_form_phone_number"
                                   value="<?php echo esc_attr(get_option('rt_powerpay_form_phone_number')) ?>"/>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row" class="titledesc">
                            <label>Dirección - shipping_address</label>
                        </th>
                        <td class="forminp forminp-checkbox">
                            <input type="text" name="rt_powerpay_form_shipping_address"
                                   id="rt_powerpay_form_shipping_address"
                                   value="<?php echo esc_attr(get_option('rt_powerpay_form_shipping_address')) ?>"/>
                        </td>
                    </tr>
                    </tbody>
                </table>
                <?php submit_button(__('Save Changes', 'woo-powerpay')); ?>
            </form>
        </div>
    </div>
    <?php
}

function rt_powerpay_submenu_settings_help()
{
    $response = wp_remote_get(rest_url('/wc/v3/system_status'));
    $data = wp_remote_retrieve_body($response);
    $environment = '';
    if($data){
        $report = wc_get_container()->get(RestApiUtil::class)->get_endpoint_data('/wc/v3/system_status');
        $environment = $report['environment'];
        $settings    = $report['settings'];
    }


    ?>
    <div class="wrap" style="background-color: #fff;">
        <div style="margin-top: 20px; padding: 20px 30px 10px 30px; background-color: #fff; min-height: 240px;width: 40%; float:left; margin-right: 20px;  border-radius: 10px ; background-position: center; background-repeat: no-repeat;background-size: cover; ">
            <h2><?php _e('Help', 'woo-powerpay') ?></h2>
            <h4>Mensaje Principal</h4>
            <p>
                Powerpay es el único medio de pago en Perú que te permite vender en cuotas sin intereses y planes
                flexibles con todas las tarjetas de crédito y sin tomar toda la línea de crédito de tu cliente. Además,
                cuenta con todo el respaldo del grupo BBVA.
            </p>
            <p>
                Si estás interesado en integrar tu negocio con Powerpay visita nuestra web: <a
                        href="https://powerpay.pe/" target="_blank" style="text-decoration: none;">Powerpay.pe</a> <br>
                o contáctanos a:
            <ul>
                <li>
                    • Email: <a href="mailto:comercio@powerpay.pe" target="_blank" style="text-decoration: none;">comercio@powerpay.pe</a>
                </li>
                <li>
                    • Teléfono: (01) 730 4556
                </li>
            </ul>
            </p>

        </div>
    </div>
    <?php if($environment){ ?>
    <div class="wrap" style="background-color: #fff;">
        <div style="margin-top: 20px; padding: 20px 30px 10px 30px; background-color: #fff; min-height: 240px;width: 40%; float:left; margin-right: 20px;  border-radius: 10px ; background-position: center; background-repeat: no-repeat;background-size: cover; ">
            <h2><?php esc_html_e('Server environment', 'woocommerce'); ?></h2>
            <table class="wc_status_table" cellspacing="0">
                <tbody>
                <tr>
                    <td data-export-label="Server Info"><?php esc_html_e( 'Server info', 'woocommerce' ); ?>:</td>
                    <td class="help"><?php echo wc_help_tip( esc_html__( 'Information about the web server that is currently hosting your site.', 'woocommerce' ) ); /* phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped */ ?></td>
                    <td><?php echo esc_html( $environment['server_info'] ); ?></td>
                </tr>
                <tr>
                    <td data-export-label="PHP Version"><?php esc_html_e('PHP version', 'woocommerce'); ?>:</td>
                    <td class="help"><?php echo wc_help_tip(esc_html__('The version of PHP installed on your hosting server.', 'woocommerce')); /* phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped */ ?></td>
                    <td>
                        <?php echo esc_html($environment['php_version']); ?>
                    </td>
                </tr>
                <tr>
                    <td data-export-label="WP Version"><?php esc_html_e( 'WordPress version', 'woocommerce' ); ?>:</td>
                    <td class="help"><?php echo wc_help_tip( esc_html__( 'The version of WordPress installed on your site.', 'woocommerce' ) ); /* phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped */ ?></td>
                    <td>
                        <?php
                        $latest_version = get_transient( 'woocommerce_system_status_wp_version_check' );

                        if ( false === $latest_version ) {
                            $version_check = wp_remote_get( 'https://api.wordpress.org/core/version-check/1.7/' );
                            $api_response  = json_decode( wp_remote_retrieve_body( $version_check ), true );

                            if ( $api_response && isset( $api_response['offers'], $api_response['offers'][0], $api_response['offers'][0]['version'] ) ) {
                                $latest_version = $api_response['offers'][0]['version'];
                            } else {
                                $latest_version = $environment['wp_version'];
                            }
                            set_transient( 'woocommerce_system_status_wp_version_check', $latest_version, DAY_IN_SECONDS );
                        }

                        if ( version_compare( $environment['wp_version'], $latest_version, '<' ) ) {
                            /* Translators: %1$s: Current version, %2$s: New version */
                            echo '<span class="dashicons dashicons-warning"></span> ' . sprintf( esc_html__( '%1$s - There is a newer version of WordPress available (%2$s)', 'woocommerce' ), esc_html( $environment['wp_version'] ), esc_html( $latest_version ) );
                        } else {
                            echo  esc_html( $environment['wp_version'] );
                        }
                        ?>
                    </td>
                </tr>
                <tr>
                    <td data-export-label="WC Version"><?php esc_html_e( 'WooCommerce version', 'woocommerce' ); ?>:</td>
                    <td class="help"><?php echo wc_help_tip( esc_html__( 'The version of WooCommerce installed on your site.', 'woocommerce' ) ); /* phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped */ ?></td>
                    <td><?php echo esc_html( ! empty( $wc_version ) ? $wc_version : $environment['version'] ); ?></td>

                </tr>
                <tr>
                    <td data-export-label="HPOS feature enabled"><?php esc_html_e( 'HPOS enabled:', 'woocommerce' ); ?></td>
                    <td class="help"><?php echo wc_help_tip( esc_html__( 'Is HPOS enabled?', 'woocommerce' ) ); ?></td>
                    <td><?php echo $settings['HPOS_enabled'] ? '<span class="dashicons dashicons-yes"></span>' : 'No'; ?></td>
                </tr>
                    <tr>
                        <td data-export-label="PHP Post Max Size"><?php esc_html_e('PHP post max size', 'woocommerce'); ?>
                            :
                        </td>
                        <td class="help"><?php echo wc_help_tip(esc_html__('The largest filesize that can be contained in one post.', 'woocommerce')); /* phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped */ ?></td>
                        <td><?php echo esc_html(size_format($environment['php_post_max_size'])); ?></td>
                    </tr>
                    <tr>
                        <td data-export-label="PHP Time Limit"><?php esc_html_e('PHP time limit', 'woocommerce'); ?>:
                        </td>
                        <td class="help"><?php echo wc_help_tip(esc_html__('The amount of time (in seconds) that your site will spend on a single operation before timing out (to avoid server lockups)', 'woocommerce')); /* phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped */ ?></td>
                        <td><?php echo esc_html($environment['php_max_execution_time']); ?></td>
                    </tr>
                    <tr>
                        <td data-export-label="PHP Max Input Vars"><?php esc_html_e('PHP max input vars', 'woocommerce'); ?>
                            :
                        </td>
                        <td class="help"><?php echo wc_help_tip(esc_html__('The maximum number of variables your server can use for a single function to avoid overloads.', 'woocommerce')); /* phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped */ ?></td>
                        <td><?php echo esc_html($environment['php_max_input_vars']); ?></td>
                    </tr>
                    <tr>
                        <td data-export-label="cURL Version"><?php esc_html_e('cURL version', 'woocommerce'); ?>:</td>
                        <td class="help"><?php echo wc_help_tip(esc_html__('The version of cURL installed on your server.', 'woocommerce')); /* phpcs:ignore WordPress.XSS.EscapeOutput.OutputNotEscaped */ ?></td>
                        <td><?php echo esc_html($environment['curl_version']); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
<?php }
}
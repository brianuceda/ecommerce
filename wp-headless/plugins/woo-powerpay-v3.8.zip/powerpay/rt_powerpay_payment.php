<?php
if (!defined('ABSPATH')) {
    exit;
}

use Automattic\WooCommerce\Utilities\OrderUtil;

add_filter('woocommerce_payment_gateways', 'rt_powerpay_add_gateway_class');
function rt_powerpay_add_gateway_class($gateways)
{
    $gateways[] = 'WC_Powerpay_Gateway';
    return $gateways;
}

add_action('plugins_loaded', 'rt_powerpay_init_gateway_class');
function rt_powerpay_init_gateway_class()
{
    class WC_Powerpay_Gateway extends WC_Payment_Gateway
    {

        public $testmode = false;
        public $private_key = '';
        public $publishable_key = '';

        public function __construct()
        {
            $this->id = 'powerpay';
            $this->has_fields = false;
            $this->method_title = 'Powerpay';
            $this->method_description = $this->init_descripcion();

            $this->supports = array(
                'products'
            );

            $this->init_form_fields();
            $this->init_settings();
            $this->title = "Powerpay";
            $this->description = $this->get_option('description');
            $this->enabled = $this->get_option('enabled');
            $this->testmode = 'yes' === $this->get_option('testmode');
            $this->private_key = $this->testmode ? $this->get_option('test_private_key') : $this->get_option('private_key');
            $this->publishable_key = $this->testmode ? $this->get_option('test_publishable_key') : $this->get_option('publishable_key');
            $this->icon = plugins_url('img/logo-powerpay.png', __FILE__);

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_api_powerpay_status_order', array($this, 'powerpay_status_order'));
        }

        public function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', 'woo-powerpay'),
                    'label' => __('Enable Powerpay', 'woo-powerpay'),
                    'type' => 'checkbox',
                    'description' => '',
                    'default' => 'no'
                ),
                'description' => array(
                    'title' => __('Description', 'woo-powerpay'),
                    'type' => 'textarea',
                    'description' => 'This controls the description which the user sees during checkout.',
                    'default' => __('Buy from 0% interest and pay later, at your own pace with the new Powerpay installment payment method. 
Today you will only pay the 1st installment with your credit card. The remaining installments will be charged every 30 days on the same card you have affiliated.', 'woo-powerpay'),
                ),
                'testmode' => array(
                    'title' => __('Test mode', 'woo-powerpay'),
                    'label' => __('Enable Test Mode', 'woo-powerpay'),
                    'type' => 'checkbox',
                    'description' => 'Place the payment gateway in test mode using test API keys.',
                    'default' => 'yes',
                    'desc_tip' => true,
                ),
            );

        }

        public function payment_fields()
        {
            if ($this->description) {
                if ($this->testmode) {
                    $this->description .= ' TEST MODE ENABLED.';
                }
                $this->description = wpautop(wp_kses_post($this->description));
                $checkout_display = esc_attr(get_option('rt_powerpay_template_display'));
                if (get_option('rt_powerpay_checkout') == "on") {
                    $cliente_key = rt_powerpay_mode_test() ? get_option('rt_powerpay_client_key_test') : get_option('rt_powerpay_client_key_pro');
                    $this->description .= '<mo-checkout product-price="' . WC()->cart->total . '" mo-client-id = "' . $cliente_key . '" theme="'.$checkout_display.'" ></mo-checkout><br>';
                }
                echo $this->description;
            }
        }

        public function init_descripcion()
        {
            return '<div class="rt-header-logo">
                <div class="rt-left-header">
                    <img width="100px"  src="' . plugins_url('img/logo-powerpay.png', __FILE__) . '"  >
                </div>
                <div>' . __("Buy now, pay later.", 'woo-powerpay') . '</div>
            </div>';
        }

        public function process_payment($order_id)
        {
            $order = new WC_Order($order_id);
            $endpoint = ($this->testmode) ? Endpoint_Test_Power_Pay : Endpoint_Pro_Power_Pay;
            $mercand_id = ($this->testmode) ? get_option('rt_powerpay_mercand_id_test') : get_option('rt_powerpay_mercand_id_pro');
            $secret_key = ($this->testmode) ? get_option('rt_powerpay_secret_key_test') : get_option('rt_powerpay_secret_key_pro');

            $auth = base64_encode($secret_key);
            
            if (class_exists(OrderUtil::class)) {

                if (OrderUtil::custom_orders_table_usage_is_enabled()) {
                    $order_data = wc_get_order($order_id);
                    $first_name = empty(get_option('rt_powerpay_form_first_name')) ? $order->get_billing_first_name() : $order_data->get_meta(get_option('rt_powerpay_form_first_name'));
                    $last_name = empty(get_option('rt_powerpay_form_last_name')) ? $order->get_billing_last_name() : $order_data->get_meta(get_option('rt_powerpay_form_last_name'));
                    $email = empty(get_option('rt_powerpay_form_email')) ? $order->get_billing_email() : $order_data->get_meta(get_option('rt_powerpay_form_email'));
                    $phone = empty(get_option('rt_powerpay_form_phone_number')) ? $order->get_billing_phone() : $order_data->get_meta(get_option('rt_powerpay_form_phone_number'));
                    $address = empty(get_option('rt_powerpay_form_shipping_address')) ? $order->get_billing_address_1() : $order_data->get_meta(get_option('rt_powerpay_form_shipping_address'));
                    $nro_dni = rt_powerpay_verify_name_field(get_option('rt_powerpay_form_document_number'),true, $order_data, $order);
                    if(!$nro_dni){
                        $nro_dni = rt_powerpay_verify_name_field('_'.get_option('rt_powerpay_form_document_number'),true, $order_data, $order);
                    }
                } else {
                    $first_name = empty(get_option('rt_powerpay_form_first_name')) ? $order->get_billing_first_name() : get_post_meta($order_id, get_option('rt_powerpay_form_first_name'), true);
                    $last_name = empty(get_option('rt_powerpay_form_last_name')) ? $order->get_billing_last_name() : get_post_meta($order_id, get_option('rt_powerpay_form_last_name'), true);
                    $email = empty(get_option('rt_powerpay_form_email')) ? $order->get_billing_email() : get_post_meta($order_id, get_option('rt_powerpay_form_email'), true);
                    $phone = empty(get_option('rt_powerpay_form_phone_number')) ? $order->get_billing_phone() : get_post_meta($order_id, get_option('rt_powerpay_form_phone_number'), true);
                    $address = empty(get_option('rt_powerpay_form_shipping_address')) ? $order->get_billing_address_1() : get_post_meta($order_id, get_option('rt_powerpay_form_shipping_address'), true);
                    $nro_dni = rt_powerpay_verify_name_field(get_option('rt_powerpay_form_document_number'),false, $order_id, $order);
                    if(!$nro_dni){
                        $nro_dni = rt_powerpay_verify_name_field('_'.get_option('rt_powerpay_form_document_number'),false, $order_id, $order);
                    }
                }
            } else {
                $first_name = empty(get_option('rt_powerpay_form_first_name')) ? $order->get_billing_first_name() : get_post_meta($order_id, get_option('rt_powerpay_form_first_name'), true);
                $last_name = empty(get_option('rt_powerpay_form_last_name')) ? $order->get_billing_last_name() : get_post_meta($order_id, get_option('rt_powerpay_form_last_name'), true);
                $email = empty(get_option('rt_powerpay_form_email')) ? $order->get_billing_email() : get_post_meta($order_id, get_option('rt_powerpay_form_email'), true);
                $phone = empty(get_option('rt_powerpay_form_phone_number')) ? $order->get_billing_phone() : get_post_meta($order_id, get_option('rt_powerpay_form_phone_number'), true);
                $address = empty(get_option('rt_powerpay_form_shipping_address')) ? $order->get_billing_address_1() : get_post_meta($order_id, get_option('rt_powerpay_form_shipping_address'), true);
                $nro_dni = rt_powerpay_verify_name_field(get_option('rt_powerpay_form_document_number'),false, $order_id, true);
                if(!$nro_dni){
                    $nro_dni = rt_powerpay_verify_name_field('_'.get_option('rt_powerpay_form_document_number'),false, $order_id, true);
                }
            }


            $trama = [
                'external_id' => uniqid() . '-' . $order->get_id(),
                'callback_url' => $order->get_checkout_order_received_url(),
                'values' => [
                    'merchant_id' => $mercand_id,
                    'currency' => 'PEN',
                    'document_type' => 'DNI',
                    'first_name' => $first_name,
                    'last_name' => $last_name,
                    'email' => $email,
                    'country_code' => "+51",
                    'phone_number' => $phone,
                    'shipping_address' => $address,

                ],
                'amount' => $order->get_total()
            ];

            if (!empty($nro_dni)) {
                $trama['values']['document_number'] = $nro_dni;
            }
            
            $trama = wp_json_encode($trama);

            $response = wp_remote_post($endpoint, [
                'method' => 'POST',
                'headers' => [
                    'Authorization' => $auth,
                    'Content-Type' => 'application/json',
                ],
                'body' => $trama,
                'timeout' => 300
            ]);

            $response_body = json_decode(wp_remote_retrieve_body($response), true);

            if (!is_wp_error($response)) {
                if ($response_body['redirection_url']) {
                    $order->update_status('pending', __('Pending', 'WC_Powerpay_Gateway'));
                    $order->reduce_order_stock();
                    WC()->cart->empty_cart();

                    if (class_exists(OrderUtil::class)) {
                        //log de la trama
                        if (OrderUtil::custom_orders_table_usage_is_enabled()) {
                            $order_data->update_meta_data('rt_powerpay_log_request', $trama);
                            $order_data->update_meta_data('rt_powerpay_log_response', $response_body);
                            $order_data->update_meta_data('rt_powerpay_transaction_id', $response_body['id']);
                            $order_data->save();
                        } else {
                            update_post_meta($order->get_id(), 'rt_powerpay_log_request', $trama);
                            update_post_meta($order->get_id(), 'rt_powerpay_log_response', $response_body);
                            update_post_meta($order->get_id(), 'rt_powerpay_transaction_id', $response_body['id']);
                        }
                    } else {
                        update_post_meta($order->get_id(), 'rt_powerpay_log_request', $trama);
                        update_post_meta($order->get_id(), 'rt_powerpay_log_response', $response_body);
                        update_post_meta($order->get_id(), 'rt_powerpay_transaction_id', $response_body['id']);
                    }

                    $order->add_order_note(__('Powerpay : Pending payment.', 'woo-powerpay'), true);
                    return array(
                        'result' => 'success',
                        'redirect' => $response_body['redirection_url']
                    );
                } else {
                    wc_add_notice(__('Powerpay : Try again.', 'woo-powerpay'), 'error');
                    error_log('Powerpay : Try again.' . json_encode($response) . "\n\n");
                }
            } else {
                wc_add_notice(__('Powerpay : Connection error.', 'woo-powerpay'), 'error');
                error_log('Powerpay : Connection error.' . json_encode($response) . "\n\n");
            }

        }

        public function powerpay_status_order()
        {

            $rawData = file_get_contents('php://input');
            $headers = apache_request_headers();
            $trama = json_decode($rawData, true);


            if ($trama['data']['status'] == 'processed') {
                $secret_key = ($this->testmode) ? get_option('rt_powerpay_secret_key_test') : get_option('rt_powerpay_secret_key_pro');
                $id = $trama['data']['id'];
                $created_at = $trama['data']['created_at'];
                $signature = $trama['data']['signature'];
                $hash = hash('sha256', $secret_key . '~' . $id . '~' . $created_at);

                if ($signature == $hash) {
                    $args = array(
                        'meta_key' => 'rt_powerpay_transaction_id',
                        'meta_value' => $id,
                        'meta_compare' => '=',
                        'return' => 'ids'
                    );

                    $orders = wc_get_orders($args);

                    $id_wc = $orders[0];
                    if ($id_wc) {
                        $order = wc_get_order($id_wc);
                        $order->update_status('wc-processing');
                        $order->add_order_note(__('Powerpay : Payment was successfully approved.', 'woo-powerpay'), true);
                        $order->reduce_order_stock();
                        update_post_meta($id_wc, 'rt_powerpay_webhook', $rawData);
                        http_response_code(200);
                        $rpt = [
                            'id' => $id,
                            'id_wc' => $id_wc,
                            'msg' => 'Webhook received successfully'
                        ];
                    } else {
                        http_response_code(400);
                        $rpt = [
                            'id' => $id,
                            'id_wc' => '',
                            'msg' => 'id_wc no search'
                        ];
                        error_log('Powerpay : notify: ' . $rawData . "\n\n");
                    }
                } else {
                    http_response_code(400);
                    $rpt = [
                        'id' => $id,
                        'hash' => $hash,
                        'id_wc' => '',
                        'msg' => 'signature and hash different'
                    ];
                    error_log('Powerpay : notify: ' . $rawData . "\n\n");
                }

            } elseif ($trama['data']['status'] == 'expired' || $trama['data']['status'] == 'canceled') {

                $secret_key = ($this->testmode) ? get_option('rt_powerpay_secret_key_test') : get_option('rt_powerpay_secret_key_pro');
                $id = $trama['data']['id'];
                $created_at = $trama['data']['created_at'];
                $signature = $trama['data']['signature'];
                $hash = hash('sha256', $secret_key . '~' . $id . '~' . $created_at);

                if ($signature == $hash) {
                    $args = array(
                        'meta_key' => 'rt_powerpay_transaction_id',
                        'meta_value' => $id,
                        'meta_compare' => '=',
                        'return' => 'ids'
                    );

                    $orders = wc_get_orders($args);

                    $id_wc = $orders[0];
                    if ($id_wc) {
                        $order = wc_get_order($id_wc);
                        $order->update_status('wc-cancelled');
                        $order->add_order_note(__('Powerpay : Payment was canceled.', 'woo-powerpay'), true);

                        update_post_meta($id_wc, 'rt_powerpay_webhook', $rawData);
                        http_response_code(200);
                        $rpt = [
                            'id' => $id,
                            'id_wc' => $id_wc,
                            'msg' => 'Webhook received successfully'
                        ];
                    } else {
                        http_response_code(400);
                        $rpt = [
                            'id' => $id,
                            'id_wc' => '',
                            'msg' => 'id_wc no search'
                        ];
                        error_log('Powerpay : notify: ' . $rawData . "\n\n");
                    }
                } else {
                    http_response_code(400);
                    $rpt = [
                        'id' => $id,
                        'hash' => $hash,
                        'id_wc' => '',
                        'msg' => 'signature and hash different'
                    ];
                    error_log('Powerpay : notify: ' . $rawData . "\n\n");
                }

            } else {
                http_response_code(400);
                $rpt = [
                    'id' => '',
                    'id_wc' => '',
                    'msg' => 'Webhook not received correctly'
                ];
                error_log('Powerpay : notify: ' . $rawData . "\n\n");
            }

            echo wp_json_encode($rpt);
            exit;
        }
    }
}

function rt_powerpay_change_order_status($order_id)
{
    if (!$order_id) {
        return;
    }
    $order = wc_get_order($order_id);

    if (isset($_GET['status']) == 'canceled' || isset($_GET['status']) == 'expired') {
        if ('pending' == $order->get_status()) {
            $order->update_status('wc-cancelled');
            $order->add_order_note(__('Powerpay : Payment canceled.', 'woo-powerpay'), true);
        }
    }

}

add_action('woocommerce_thankyou', 'rt_powerpay_change_order_status', '99');

function rt_powerpay_endpoint_order_received_title($title, $endpoint, $action)
{
    global $wp;

    $order_id = isset($wp->query_vars['order-received']) ? $wp->query_vars['order-received'] : 0;
    $order = wc_get_order($order_id);

    if ($order->payment_method == 'powerpay') {

        $status = isset($_GET['status']) ? $_GET['status'] : 0;

        switch ($status) {
            case 'canceled':
            case 'expired':
                $name_title = __('<i class="fas fa-exclamation-circle me-2"></i> You have not completed your purchase', 'woo-powerpay');
                $name_desc = __('Choose your product again, and continue your payment with Powerpay', 'woo-powerpay');
                break;
            case 'processed':
                $name_title = __('<i class="fas fa-check-circle me-2"></i> Thank you. Your payment has been successfully processed.', 'woo-powerpay');
                $name_desc = '';
                break;
        }

        $title = '<style>
                .woocommerce-thankyou-order-received {
                    display: none;
                }
                .woocommerce-thankyou-order-received-powerpay {
                    padding: 36px 0;
                    font-size: 20px;
                    font-weight: 700;
                    letter-spacing: -0.025em;
                    border: 2px solid rgb(153, 48, 226);
                    color: #fff;
                    background-color: rgb(153, 48, 226);
                    text-align: center !important;
                }
                .woocommerce-thankyou-order-received-powerpay-desc {
                    font-size: 15px;
                    font-weight: 400;
                }
                .woocommerce-thankyou-order-received-powerpay i {
                        color: #fff;
                        font-size: 30px;
                        vertical-align: middle;
                    }
                </style>
                <p class="woocommerce-thankyou-order-received-powerpay">
                ' . $name_title . ' <br>
                    <small class="woocommerce-thankyou-order-received-powerpay-desc"> ' . $name_desc . '</small>
                </p>
                ';
    }

    switch (get_option('rt_powerpay_checkout_display')) {
        case 'echo':
            echo $title;
            break;
        case 'return':
        default:
            return $title;
    }

}

add_filter('woocommerce_endpoint_order-received_title', 'rt_powerpay_endpoint_order_received_title', 10, 3);

function rt_powerpay_thank_you_details($thank_you_title, $order)
{
    global $wp;
    $order_id = isset($wp->query_vars['order-received']) ? absint($wp->query_vars['order-received']) : 0;
    $order = wc_get_order($order_id);

    if ($order && $order->has_status('cancelled')) {
        return '';
    }

    return $thank_you_title;
}

add_filter('woocommerce_thankyou_order_received_text', 'rt_powerpay_thank_you_details', 20, 2);

function rt_powerpay_remove_myaccount_orders_cancel_button($actions, $order)
{
    unset($actions['pay']);
    return $actions;
}

add_filter('woocommerce_my_account_my_orders_actions', 'rt_powerpay_remove_myaccount_orders_cancel_button', 10, 2);

function rt_powerpay_checkout_style()
{
    if (is_checkout() == true) {

        echo '<style> 
        #payment .payment_method_powerpay label {
            display: unset !important;
        }
        #payment .payment_method_powerpay img {
            float: right !important;
            margin: 5px 0 0 0.5em !important;
        }
        </style>';
    }
}

add_action('wp_head', 'rt_powerpay_checkout_style');

function rt_powerpay_verify_name_field($field, $order, $order_data, $get_order)
{
    switch ($field) {
        case 'billing_company';
            return $get_order->get_billing_company();
            break;
        default:
            if ($order) {
                return $order_data->get_meta($field);
            } else {
                return get_post_meta($order_data, $field, true);
            }
            break;
    }
}




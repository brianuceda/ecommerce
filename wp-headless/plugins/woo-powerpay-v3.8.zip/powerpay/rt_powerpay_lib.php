<?php
if (!defined('ABSPATH')) {
    exit;
}
function rt_powerpay_add_cors_http_header()
{
    if (!headers_sent()) {
        header('Access-Control-Allow-Origin: *');
        header('Access-Control-Allow-Headers: X-Requested-With, Content-Type, Origin, Cache-Control, Pragma, Authorization, Accept, Accept-Encoding');
    }
}

add_action('send_headers', 'rt_powerpay_add_cors_http_header');

function rt_powerpay_mode_test()
{
    $payment_gateway_id = Name_RT_Power_Pay;
    $payment_gateways = WC_Payment_Gateways::instance();
    $payment_gateway = $payment_gateways->payment_gateways()[$payment_gateway_id];
    return $payment_gateway->testmode;
}

function rt_powerpay_widget_js_header()
{
    $rt_powerpay_css = rt_powerpay_mode_test() ? CSS_Test_Power_Pay : CSS_Pro_Power_Pay;

    wp_register_style('rt-powerpay', $rt_powerpay_css);
    wp_enqueue_style('rt-powerpay');
}

add_action('wp_head', 'rt_powerpay_widget_js_header');

function rt_powerpay_js_header()
{
    $rt_powerpay_js = rt_powerpay_mode_test() ? JS_Test_Power_Pay : JS_Pro_Power_Pay;

    wp_print_script_tag(
        array(
            'id' => 'rt-powerpay',
            'src' => esc_attr($rt_powerpay_js),
            'type' => 'module'
        )
    );
}

add_action('wp_enqueue_scripts', 'rt_powerpay_js_header');

if (get_option('rt_powerpay_header') == "on") {
    add_action('wp_body_open', 'rt_powerpay_body_open');
}
function rt_powerpay_body_open()
{
    $checkout_display = esc_attr(get_option('rt_powerpay_template_display'));
    $cliente_key = rt_powerpay_mode_test() ? get_option('rt_powerpay_client_key_test') : get_option('rt_powerpay_client_key_pro');
    echo '<mo-header mo-client-id="' . $cliente_key . '" theme="'.$checkout_display.'" ></mo-header>';
}

if (get_option('rt_powerpay_banner') == "on") {
    add_action('wp_footer', 'rt_powerpay_footer');
}

function rt_powerpay_footer()
{
    $checkout_display = esc_attr(get_option('rt_powerpay_template_display'));

    $cliente_key = rt_powerpay_mode_test() ? get_option('rt_powerpay_client_key_test') : get_option('rt_powerpay_client_key_pro');
    echo '<mo-banner mo-client-id="' . $cliente_key . '" theme="'.$checkout_display.'" ></mo-banner>';
}

function rt_powerpay_price_html($price_html, $product)
{
    global $woocommerce_loop;
    $checkout_display = esc_attr(get_option('rt_powerpay_template_display'));
    if (is_product() && !$woocommerce_loop['name'] == 'related') {
        $precio = $product->get_price();
        $cliente_key = rt_powerpay_mode_test() ? get_option('rt_powerpay_client_key_test') : get_option('rt_powerpay_client_key_pro');
        if ($precio > 0) {
            $price_html = $price_html . '<br><br>
                <mo-product-page product-price="' . $precio . '" mo-client-id="' . $cliente_key . '" theme="'.$checkout_display.'" ></mo-product-page>';
        }
    }
    return $price_html;
}

if (get_option('rt_powerpay_detalle') == "on") {
    switch (get_option('rt_powerpay_detalle_position')){
        case 'add_cart':
            add_filter('woocommerce_before_add_to_cart_quantity', 'rt_powerpay_after_add_to_cart_quantity');
            break;
        case 'before_add_cart':
            add_filter('woocommerce_before_add_to_cart_form', 'rt_powerpay_after_add_to_cart_quantity');
            break;
        case 'price':
        default:
        add_filter('woocommerce_get_price_html', 'rt_powerpay_price_html', 10, 2);
            break;
    }
}


function rt_powerpay_after_add_to_cart_quantity()
{
    global $woocommerce_loop;
    $checkout_display = esc_attr(get_option('rt_powerpay_template_display'));
    $product = new WC_Product(get_the_ID());
    if (is_product() && !$woocommerce_loop['name'] == 'related') {
        $precio = $product->get_price();
        $cliente_key = rt_powerpay_mode_test() ? get_option('rt_powerpay_client_key_test') : get_option('rt_powerpay_client_key_pro');
        if ($precio > 0) {
            $price_html = '
                <mo-product-page product-price="' . $precio . '" mo-client-id="' . $cliente_key . '" theme="'.$checkout_display.'"></mo-product-page> <br>';
        }
    }
    echo $price_html;
}




add_action('woocommerce_email', 'rt_powerpay_emails_order_notes', 10);
function rt_powerpay_emails_order_notes($email_class)
{
    remove_action('woocommerce_new_customer_note_notification', [$email_class->emails['WC_Email_Customer_Note'], 'trigger']);
}


add_shortcode('powerpay_widget_header', 'rt_powerpay_widget_header');

function rt_powerpay_widget_header()
{
    $checkout_display = esc_attr(get_option('rt_powerpay_template_display'));

    $cliente_key = rt_powerpay_mode_test() ? get_option('rt_powerpay_client_key_test') : get_option('rt_powerpay_client_key_pro');
    return '<mo-header mo-client-id="' . $cliente_key . '" theme="'.$checkout_display.'" ></mo-header>';
}

add_shortcode('powerpay_widget_banner', 'rt_powerpay_widget_banner');

function rt_powerpay_widget_banner()
{
    $checkout_display = esc_attr(get_option('rt_powerpay_template_display'));

    $cliente_key = rt_powerpay_mode_test() ? get_option('rt_powerpay_client_key_test') : get_option('rt_powerpay_client_key_pro');
    return '<mo-banner mo-client-id="' . $cliente_key . '" theme="'.$checkout_display.'"></mo-banner>';
}

add_shortcode('powerpay_widget_detail', 'rt_powerpay_widget_detail');

function rt_powerpay_widget_detail($atts)
{
    $checkout_display = esc_attr(get_option('rt_powerpay_template_display'));

    $cliente_key = rt_powerpay_mode_test() ? get_option('rt_powerpay_client_key_test') : get_option('rt_powerpay_client_key_pro');
    $price_html = '<mo-product-page product-price="' . $atts['price'] . '" mo-client-id="' . $cliente_key . '" theme="'.$checkout_display.'" ></mo-product-page>';
    return $price_html;
}

add_shortcode('powerpay_widget_checkout', 'rt_powerpay_widget_checkout');

function rt_powerpay_widget_checkout($atts)
{
    $checkout_display = esc_attr(get_option('rt_powerpay_template_display'));

    $cliente_key = rt_powerpay_mode_test() ? get_option('rt_powerpay_client_key_test') : get_option('rt_powerpay_client_key_pro');
    return '<mo-checkout product-price="' . $atts['total'] . '" mo-client-id = "' . $cliente_key . '" theme="'.$checkout_display.'" ></mo-checkout><br>';
}

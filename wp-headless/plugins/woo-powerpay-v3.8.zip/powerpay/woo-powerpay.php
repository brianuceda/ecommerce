<?php
/**
 * Powerpay para WooCommerce
 *
 *
 * Plugin Name:       Powerpay para WooCommerce
 * Plugin URI:        https://huako.tech/
 * Description:       Compra ahora y paga después con Powerpay, tu nueva forma de pago con cuotas desde 0% intereses.
 * Version:           3.8
 * Author:            Huako Tech
 * Author URI:        https://huako.tech/
 * License:           GNU General Public License v3.0
 * License URI:       http://www.gnu.org/licenses/gpl-3.0.html
 * Text Domain:       woo-powerpay
 * Domain Path:       /language
 * Requires at least: 6.5
 * Requires PHP:      7.4
 * WC tested up to:   9.7.1
 * WC requires at least: 7.4
 */
if (!defined('ABSPATH')) {
    exit;
}

$plugin_power_pay_version = get_file_data(__FILE__, array('Version' => 'Version'), false);

define('Name_RT_Power_Pay', 'powerpay');
define('Version_RT_Power_Pay', $plugin_power_pay_version['Version']);
define('Endpoint_Pro_Power_Pay', 'https://api.powerpay.pe/api/merchant-transactions');
define('Endpoint_Test_Power_Pay', 'https://mo-services-bbva-bnpl-pe-green.moprestamo.com/api/merchant-transactions');
define('JS_Pro_Power_Pay', 'https://components-bnpl-pe-bbva-production.moprestamo.com/cdn/dist/powerpay-components/powerpay-components.esm.js');
define('JS_Test_Power_Pay', 'https://components-bnpl-pe-bbva-green.moprestamo.com/cdn/dist/powerpay-components/powerpay-components.esm.js');
define('CSS_Pro_Power_Pay', 'https://components-bnpl-pe-bbva-production.moprestamo.com/css/config.css');
define('CSS_Test_Power_Pay', 'https://components-bnpl-pe-bbva-green.moprestamo.com/css/config.css');

add_action( 'before_woocommerce_init', function() {
    if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
    }
} );

function rt_powerpay_load_textdomain()
{
    load_plugin_textdomain('woo-powerpay', false, basename(dirname(__FILE__)) . '/language/');
}

add_action('init', 'rt_powerpay_load_textdomain');

add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'rt_powerpay_page_settings_link');

function rt_powerpay_page_settings_link($links)
{
    $links2[] = '<a href="' . admin_url('admin.php?page=rt_powerpay_settings&tab=settings') . '">' . __('Settings', 'woo-powerpay') . '</a>';

    $links = array_merge($links2, $links);
    return $links;
}

/*
 * LIB
 */
require dirname(__FILE__) . "/rt_powerpay_lib.php";

/*
 * ADMIN
 */
require dirname(__FILE__) . "/rt_powerpay_admin.php";

/*
 * PAYMENT
 */
require dirname(__FILE__) . "/rt_powerpay_payment.php";

